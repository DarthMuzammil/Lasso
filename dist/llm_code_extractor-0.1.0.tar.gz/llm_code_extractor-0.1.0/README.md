# Lasso
This is a Lasso to make your LLMs behave. llm code extractor
