class LLMOutputException(Exception):
    """Custom exception for LLM output validation failures."""
    pass
